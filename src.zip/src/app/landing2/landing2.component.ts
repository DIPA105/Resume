import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing2',
  template: `
    <p>
      landing2 works!
    </p>
  `,
  styleUrls: ['./landing2.component.css']
})
export class Landing2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
