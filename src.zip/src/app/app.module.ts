import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserAuthModule } from './user-auth/user-auth.module';
import { Landing1Component } from './landing1/landing1.component';
import { Landing2Component } from './landing2/landing2.component';
import { Landing3Component } from './landing3/landing3.component';
import { MainComponent } from './main/main.component';
import { WorkExperienceComponent } from './main/work-experience/work-experience.component';
import { EducationComponent } from './main/education/education.component';
import { FooterComponent } from './main/footer/footer.component';
import { SidebarComponent } from './main/sidebar/sidebar.component';
import { ProfileComponent } from './main/sidebar/profile/profile.component';
import { SkillsComponent } from './main/sidebar/skills/skills.component';
import { LanguagesComponent } from './main/sidebar/languages/languages.component';





@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    Landing1Component,
    Landing2Component,
    Landing3Component,
    MainComponent,
    WorkExperienceComponent,
    EducationComponent,
    FooterComponent,
    SidebarComponent,
    ProfileComponent,
    SkillsComponent,
    LanguagesComponent,
    
    
   
    
    
    
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
