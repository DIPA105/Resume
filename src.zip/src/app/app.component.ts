import { Component } from '@angular/core';
// import { SSL_OP_SSLEAY_080_CLIENT_DH_BUG } from 'constants';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Ecommerce';
  // name = "dipa";
  // age = 21;
  // salary = 89000;

// x=0;
// y=0;
// z=0;
// b=0;
// a=0;
// c=0;

// d=0;
// e=0;
// f=0;
// g=0;
// h=0;
// i=0;
// MoveFunction(){
//   this.x++;
// }
// OverFunction(){
//   this.y++;
// }
// EnterFunction(){
//   this.z++;
// }
// DownFunction(){
//   this.b++;
// }
// LeaveFunction(){
//   this.a++;
// }
// UpFunction(){
//   this.c++;
// }


// ClickFunction(){
//   this.d++;
// }
// ChangeFunction(){
//   this.e++;
// }
// DblclickFunction(){
//   this.f++;
// }
// FocusFunction(){
//   this.g++;
// }
// KeydownFunction(){
//   this.h++;
// }
// KeypressFunction(){
//   this.i++;
// }
}
