import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmailverificationComponent } from './emailverification/emailverification.component';
import { EmailsendComponent } from './emailsend/emailsend.component';
import { OtpComponent } from './otp/otp.component';



@NgModule({
  declarations: [
    EmailverificationComponent,
    EmailsendComponent,
    OtpComponent
  ],
  imports: [
    CommonModule
  ],
  exports:[
    OtpComponent,
    EmailsendComponent,
    EmailverificationComponent
  ]
})
export class UserAuthModule { }
