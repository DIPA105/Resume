import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emailsend',
  templateUrl: './emailsend.component.html',
  styleUrls: ['./emailsend.component.css']
})
export class EmailsendComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
