import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing3',
  template: `
    <p>
      landing3 works!
    </p>
  `,
  styles: [
  ]
})
export class Landing3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
