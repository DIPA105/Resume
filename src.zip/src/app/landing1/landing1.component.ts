import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landing1',
  templateUrl: './landing1.component.html',
  styles: [
  ]
})
export class Landing1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
